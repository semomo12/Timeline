#!/bin/bash
export PYTHONPATH=.
python3 app/main.py